# Reproduction of Himes et al. 2014 (GSE52778): DEX vs untreated

## Goal
Reproduce the dexamethasone vs untreated analysis in human airway smooth-muscle cells and compare it with the published 316 differentially expressed genes.

## Data (also in results/tables/download_log.csv)
| File | Type | Size | Date |
|---|---|---|---|
| GSE52778_All_Sample_FPKM_Matrix.txt.gz | processed | 2536 KB | 2026-10-05 |
| GSE52778_Dex_vs_Untreated_gene_exp.diff.gz | processed | 830 KB | 2026-10-05 |
| GSE52778_series_matrix.txt.gz | metadata | 3 KB | 2026-10-05 |
| airway_1.30.0.tar.gz | processed (counts, R package) | 24176 KB | 2026-10-05 |

Source: GEO accession GSE52778 (NCBI). Files in data/raw/ are as downloaded. In GEO's terms the FPKM matrix and Cuffdiff results are processed data; the raw sequencing reads are in SRA and were not downloaded.
The paper was saved as data/raw/himes2014_plosone.xml (PLOS ONE, doi 10.1371/journal.pone.0099625).

## Sample identity
GSM to LL## IDs came from the SRA experiment records (SRX384345-SRX384360). 15 of 16 SRA records were retrieved live; the 16th (SRX384347, an albuterol-only sample) was taken from my first run.
The mapping was checked against the FPKM column names (all 16 matched) and against the Bioconductor airway object (GSM, donor and condition matched for all 8 samples).

## How to run
1. Run notebooks/RNAseq_reproduction.ipynb down to the Part 7 heading.
2. Run notebooks/deseq2_analysis.R in R. It writes results/deseq2_results.csv. Edit the setwd() path first.
3. Run the rest of the notebook (Parts 7-12).

Software: Python 3.13.9 (pandas, numpy, matplotlib, scikit-learn, requests); R 4.5.3, Bioconductor 3.22, DESeq2 1.50.2, SummarizedExperiment 1.40.0, airway 1.30.0. airway 1.30.0 was installed in R from a tarball downloaded from Bioconductor 3.22.

## Results summary
- DESeq2 (~ cell + dex): 16,782 genes tested, 4,028 significant at padj < 0.05 (2,211 up, 1,817 down). Paper: 316 (+3,712).
- DESeq2 (~ dex, donor ignored): 2,700.
- Authors' Cuffdiff file: exactly 316 genes at q < 0.05.
- 301 of the 316 published genes were also significant here, all in the same direction.
- DUSP1, KLF15, PER1, TSC22D3, C7, CCDC69 and CRISPLD2 were all reproduced.
- Biological conclusion reproduced; the published gene count was reproduced only from the authors' own file.

## Notes
- Cuffdiff's log2(fold_change) is untreated/DEX (sample_1 = Dex), so its sign was flipped before comparison.
- airway uses Ensembl/GRCh37 counts; the paper used RefSeq/hg19 with Cufflinks/Cuffdiff.
- Matching between the two gene lists is by symbol, so some of the 15 unmatched genes may be annotation differences.

## Files
- results/tables: download log, metadata, top 20 genes, significant genes, part 8 comparison, part 9 genes, the 15-gene classification, final reproducibility table, R console output
- results/figures: Figures 1-4 (QC), log2FC distribution, CRISPLD2 paired plot, volcano plot

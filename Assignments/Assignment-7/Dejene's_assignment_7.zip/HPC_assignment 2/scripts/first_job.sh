#!/bin/bash

#SBATCH --job-name=first_job
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:10:00
#SBATCH --output=logs/first_job_%j.out
#SBATCH --error=logs/first_job_%j.err

echo "========================================"
echo "First SLURM Job"
echo "========================================"

echo "Job ID: $SLURM_JOB_ID"
echo "Job Name: $SLURM_JOB_NAME"
echo "Hostname: $(hostname)"
echo "Working directory: $(pwd)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"
echo "Start time: $(date)"

sleep 30

echo "End time: $(date)"
echo "Job completed."

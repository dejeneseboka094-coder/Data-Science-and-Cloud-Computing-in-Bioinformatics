#!/bin/bash

#SBATCH --job-name=variant_calling
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/variant_calling_%j.out
#SBATCH --error=logs/variant_calling_%j.err

echo "Variant calling stage started"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 5

echo "Variant calling completed"
echo "Completed: $(date)"

#!/bin/bash
#SBATCH --job-name=test_oom
#SBATCH --cpus-per-task=1
#SBATCH --mem=100M
#SBATCH --time=00:02:00
#SBATCH --output=logs/test_oom_%j.out
#SBATCH --error=logs/test_oom_%j.err

echo "Job ID: $SLURM_JOB_ID"
echo "Requested memory: 100M"
echo "Starting memory allocation..."

python - <<'PY'
x = bytearray(500 * 1024 * 1024)
print("Allocated 500 MB")
PY

echo "Job completed"

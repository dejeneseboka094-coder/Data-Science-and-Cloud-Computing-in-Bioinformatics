#!/bin/bash
#SBATCH --job-name=quantification
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/k_quant_%j.out
#SBATCH --error=logs/k_quant_%j.err

echo "Quantification stage"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 5

echo "Sample	Gene_Count" > results/quantification/sample_counts.tsv
echo "sample_01	1000" >> results/quantification/sample_counts.tsv

echo "Quantification completed"
echo "Completed: $(date)"

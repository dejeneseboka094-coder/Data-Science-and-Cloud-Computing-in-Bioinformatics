#!/bin/bash
#SBATCH --job-name=RNA_align
#SBATCH --cpus-per-task=2
#SBATCH --mem=2G
#SBATCH --time=00:02:00
#SBATCH --output=logs/k_alignment_%j.out
#SBATCH --error=logs/k_alignment_%j.err

echo "RNA-seq alignment stage"
echo "Job ID: $SLURM_JOB_ID"
echo "CPUs: $SLURM_CPUS_PER_TASK"
echo "Start: $(date)"

sleep 5

echo "Alignment completed"
echo "Completed: $(date)"

#!/bin/bash
#SBATCH --job-name=sort_BAM
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/k_sort_%j.out
#SBATCH --error=logs/k_sort_%j.err

echo "BAM sorting stage"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 5

touch results/bam/sample_sorted.bam

echo "BAM sorting completed"
echo "Completed: $(date)"

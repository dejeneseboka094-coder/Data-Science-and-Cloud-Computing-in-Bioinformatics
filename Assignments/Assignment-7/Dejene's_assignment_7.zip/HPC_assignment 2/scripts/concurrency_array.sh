#!/bin/bash

#SBATCH --job-name=concurrency
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:05:00
#SBATCH --output=logs/concurrency_%A_%a.out
#SBATCH --error=logs/concurrency_%A_%a.err

echo "========================================"
echo "Concurrency Control Demonstration"
echo "========================================"

echo "Array Job ID: $SLURM_ARRAY_JOB_ID"
echo "Array Task ID: $SLURM_ARRAY_TASK_ID"
echo "Job ID: $SLURM_JOB_ID"
echo "Hostname: $(hostname)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"
echo "Start time: $(date)"

echo "Task $SLURM_ARRAY_TASK_ID is running."

sleep 10

echo "Task $SLURM_ARRAY_TASK_ID completed."
echo "End time: $(date)"

#!/bin/bash

#SBATCH --job-name=fastq_stage
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/fastq_stage_%j.out
#SBATCH --error=logs/fastq_stage_%j.err

echo "FASTQ stage started"
echo "Job ID: $SLURM_JOB_ID"
echo "Hostname: $(hostname)"
echo "Start: $(date)"

sleep 5

echo "FASTQ processing completed"
echo "Completed: $(date)"

#!/bin/bash

#SBATCH --job-name=multithread
#SBATCH --cpus-per-task=2
#SBATCH --mem=2G
#SBATCH --time=00:05:00
#SBATCH --output=logs/multithread_%j.out
#SBATCH --error=logs/multithread_%j.err

echo "========================================"
echo "Multithreaded SLURM Job"
echo "========================================"

echo "Job ID: $SLURM_JOB_ID"
echo "Job Name: $SLURM_JOB_NAME"
echo "Hostname: $(hostname)"
echo "Working directory: $(pwd)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"
echo "Start time: $(date)"

echo ""
echo "Testing SLURM CPU allocation..."

for i in $(seq 1 "$SLURM_CPUS_PER_TASK")
do
    echo "Thread $i running"
done

echo ""
echo "End time: $(date)"
echo "Job completed."

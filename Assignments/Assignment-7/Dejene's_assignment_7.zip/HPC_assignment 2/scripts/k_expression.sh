#!/bin/bash
#SBATCH --job-name=expression_matrix
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/k_expression_%j.out
#SBATCH --error=logs/k_expression_%j.err

echo "Expression matrix generation"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 5

cat > results/expression/expression_matrix.tsv <<'MATRIX'
Gene	sample_01
Gene_001	100
Gene_002	250
Gene_003	175
MATRIX

echo "Expression matrix completed"
echo "Completed: $(date)"

#!/bin/bash

#SBATCH --job-name=sample_array
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:05:00
#SBATCH --output=logs/array_%A_%a.out
#SBATCH --error=logs/array_%A_%a.err

SAMPLE=$(sed -n "${SLURM_ARRAY_TASK_ID}p" data/samples.txt)

echo "========================================"
echo "SLURM Job Array Task"
echo "========================================"

echo "Array Job ID: $SLURM_ARRAY_JOB_ID"
echo "Array Task ID: $SLURM_ARRAY_TASK_ID"
echo "Job ID: $SLURM_JOB_ID"
echo "Sample: $SAMPLE"
echo "Hostname: $(hostname)"
echo "Working directory: $(pwd)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"
echo "Start time: $(date)"

echo "Processing $SAMPLE..."

sleep 2

echo "Sample processing completed."

echo "Sample: $SAMPLE" > "results/${SAMPLE}_result.txt"
echo "Array Job ID: $SLURM_ARRAY_JOB_ID" >> "results/${SAMPLE}_result.txt"
echo "Array Task ID: $SLURM_ARRAY_TASK_ID" >> "results/${SAMPLE}_result.txt"
echo "Completed: $(date)" >> "results/${SAMPLE}_result.txt"

echo "End time: $(date)"

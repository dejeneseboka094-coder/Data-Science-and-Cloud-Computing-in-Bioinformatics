#!/bin/bash
#SBATCH --job-name=better_request
#SBATCH --cpus-per-task=2
#SBATCH --mem=2G
#SBATCH --time=01:00:00

echo "Resource request optimized based on observed workload."

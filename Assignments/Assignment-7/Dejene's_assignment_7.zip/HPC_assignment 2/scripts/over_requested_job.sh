#!/bin/bash
#SBATCH --job-name=over_requested
#SBATCH --cpus-per-task=64
#SBATCH --mem=256G
#SBATCH --time=48:00:00

echo "This is an intentionally over-requested configuration."
echo "Actual workload requires approximately:"
echo "CPUs: 1"
echo "Memory: 12G"
echo "Runtime: 35 minutes"

#!/bin/bash

#SBATCH --job-name=alignment
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/alignment_%j.out
#SBATCH --error=logs/alignment_%j.err

echo "Alignment stage started"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 5

echo "Alignment completed"
echo "Completed: $(date)"

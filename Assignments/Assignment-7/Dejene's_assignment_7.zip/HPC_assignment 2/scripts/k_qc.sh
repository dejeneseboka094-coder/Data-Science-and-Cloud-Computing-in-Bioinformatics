#!/bin/bash
#SBATCH --job-name=RNA_QC
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/k_qc_%A_%a.out
#SBATCH --error=logs/k_qc_%A_%a.err

SAMPLE=$(sed -n "${SLURM_ARRAY_TASK_ID}p" data/samples.txt)

echo "RNA-seq QC stage"
echo "Array Job ID: $SLURM_ARRAY_JOB_ID"
echo "Task ID: $SLURM_ARRAY_TASK_ID"
echo "Sample: $SAMPLE"
echo "CPUs: $SLURM_CPUS_PER_TASK"
echo "Start: $(date)"

sleep 5

echo "QC completed"
echo "Completed: $(date)"

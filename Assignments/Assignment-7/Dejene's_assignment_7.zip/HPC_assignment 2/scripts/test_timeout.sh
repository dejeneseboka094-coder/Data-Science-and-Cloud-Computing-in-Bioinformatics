#!/bin/bash
#SBATCH --job-name=test_timeout
#SBATCH --cpus-per-task=1
#SBATCH --mem=512M
#SBATCH --time=00:00:10
#SBATCH --output=logs/test_timeout_%j.out
#SBATCH --error=logs/test_timeout_%j.err

echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"

sleep 30

echo "Job completed"
